import boto3

table_name = "Visitors"
dynamodb = boto3.resource("dynamodb")
client = boto3.client("dynamodb")
table = dynamodb.Table(table_name)


def add_visitor():
    response = client.update_item(
        TableName=table_name,
        Key={"visitor": {"N": "0"}},
        ExpressionAttributeValues={":val": {"N": "1"}},
        UpdateExpression="ADD Visitor :val")


def get_count():
    item = client.get_item(TableName=table_name, Key={"visitor": {"N": "0"}})
    count = item["Item"]["Visitor"]["N"]
    return count


def lambda_handler(event, context):
    add_visitor()
    return get_count()


